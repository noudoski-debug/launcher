package com.kyy.launcher

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.provider.AlarmClock
import android.widget.RemoteViews

abstract class BaseWidget(
    private val layout: Int,
    private val openCalendar: Boolean = false
) : AppWidgetProvider() {
    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        val intent = if (openCalendar)
            Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALENDAR)
        else Intent(AlarmClock.ACTION_SHOW_ALARMS)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val pi = PendingIntent.getActivity(ctx, if (openCalendar) 1 else 0, intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        for (id in ids) {
            val rv = RemoteViews(ctx.packageName, layout)
            rv.setOnClickPendingIntent(R.id.root, pi)
            mgr.updateAppWidget(id, rv)
        }
    }
}

class ClockWidget : BaseWidget(R.layout.widget_clock)
class StackClockWidget : BaseWidget(R.layout.widget_stack)
class AnalogClockWidget : BaseWidget(R.layout.widget_analog)
class DateWidget : BaseWidget(R.layout.widget_date, openCalendar = true)
class MiniClockWidget : BaseWidget(R.layout.widget_mini)
