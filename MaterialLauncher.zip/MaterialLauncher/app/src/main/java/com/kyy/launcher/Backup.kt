package com.kyy.launcher

import android.content.Context
import android.content.pm.PackageManager
import java.io.File

/** Установлено ли приложение прямо сейчас. При сомнении (любая другая ошибка) считаем, что установлено. */
fun isPkgInstalled(pkg: String): Boolean = try {
    App.ctx.packageManager.getApplicationInfo(pkg, 0); true
} catch (e: PackageManager.NameNotFoundException) { false } catch (e: Throwable) { true }

/**
 * Копии раскладки (главный экран, папки, док) в файлах приложения: последние [GENERATIONS] разных состояний.
 * Если раскладка вдруг стала пустой, при запуске возвращаем последнюю копию; вручную можно вернуть самую полную.
 */
object LayoutBackup {
    private const val GENERATIONS = 8
    private lateinit var dir: File

    fun init(ctx: Context) { dir = ctx.filesDir }

    private fun file(i: Int) = File(dir, "layout_backup_$i.txt")
    private fun count(items: String) = items.split(";").count { it.isNotBlank() }

    private fun read(i: Int): Triple<String, String, String>? = try {
        val f = file(i)
        if (!f.exists()) null else f.readText().split("\n").let { if (it.size == 3) Triple(it[0], it[1], it[2]) else null }
    } catch (_: Throwable) { null }

    @Synchronized
    fun save() {
        val items = prefs.homeItems
        if (items.isEmpty()) return   // пустое состояние копией не делаем: оно как раз то, от чего копия защищает
        val now = listOf(items, prefs.folders, prefs.dock).joinToString("\n")
        try {
            val newest = file(0)
            if (newest.exists() && newest.readText() == now) return
            for (i in GENERATIONS - 1 downTo 1) {
                val from = file(i - 1)
                if (from.exists()) from.copyTo(file(i), overwrite = true)
            }
            val tmp = File(dir, "layout_backup.tmp")
            tmp.writeText(now)
            tmp.copyTo(file(0), overwrite = true)
            tmp.delete()
        } catch (_: Throwable) {}
        if (prefs.homeCleared) prefs.homeCleared = false
    }

    private fun apply(t: Triple<String, String, String>) {
        prefs.homeItems = t.first
        prefs.folders = t.second
        if (t.third.isNotEmpty()) { prefs.dock = t.third; prefs.dockInit = true }
        prefs.homeMigrated = true
        prefs.homeCleared = false
    }

    /** Запуск: на главном экране пусто, хотя копия есть (и пользователь сам его не очищал) — возвращаем последнюю копию. */
    @Synchronized
    fun restoreIfEmpty() {
        if (prefs.homeItems.isNotEmpty() || prefs.homeCleared) return
        val t = read(0) ?: return
        if (t.first.isNotEmpty()) apply(t)
    }

    /** Вручную: вернуть самую полную из копий (при равенстве — самую свежую). false, если копий нет. */
    @Synchronized
    fun restoreBest(): Boolean {
        var best: Triple<String, String, String>? = null
        var bestN = 0
        for (i in 0 until GENERATIONS) {
            val t = read(i) ?: continue
            val n = count(t.first)
            if (n > bestN) { best = t; bestN = n }
        }
        val b = best ?: return false
        apply(b)
        return true
    }
}
