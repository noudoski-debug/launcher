package com.kyy.launcher

import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import androidx.graphics.shapes.CornerRounding
import androidx.graphics.shapes.RoundedPolygon
import androidx.graphics.shapes.star

class PolyShape(private val poly: RoundedPolygon) : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val path = Path()
        val w = size.width / 2f
        val h = size.height / 2f
        var first = true
        for (c in poly.cubics) {
            if (first) {
                path.moveTo((c.anchor0X + 1f) * w, (c.anchor0Y + 1f) * h)
                first = false
            }
            path.cubicTo(
                (c.control0X + 1f) * w, (c.control0Y + 1f) * h,
                (c.control1X + 1f) * w, (c.control1Y + 1f) * h,
                (c.anchor1X + 1f) * w, (c.anchor1Y + 1f) * h
            )
        }
        path.close()
        return Outline.Generic(path)
    }
}

val ShapeNames = listOf(
    "circle" to "Круг",
    "squircle" to "Сквиркл",
    "rounded" to "Скруглённый",
    "square" to "Квадрат",
    "teardrop" to "Капля",
    "cookie" to "Печенье",
    "flower" to "Цветок",
    "scallop" to "Волна",
    "clover" to "Клевер",
    "pentagon" to "Пятиугольник",
    "hexagon" to "Шестиугольник"
)

private val shapeCache = HashMap<String, Shape>()

fun shapeOf(name: String): Shape = shapeCache.getOrPut(name) {
    when (name) {
        "circle" -> CircleShape
        "squircle" -> RoundedCornerShape(35)
        "rounded" -> RoundedCornerShape(22)
        "square" -> RoundedCornerShape(8)
        "teardrop" -> RoundedCornerShape(
            topStartPercent = 50, topEndPercent = 50, bottomEndPercent = 8, bottomStartPercent = 50
        )
        "cookie" -> PolyShape(RoundedPolygon.star(10, 1f, 0.87f, CornerRounding(0.55f)))
        "flower" -> PolyShape(RoundedPolygon.star(8, 1f, 0.72f, CornerRounding(0.4f)))
        "scallop" -> PolyShape(RoundedPolygon.star(12, 1f, 0.9f, CornerRounding(0.6f)))
        "clover" -> PolyShape(RoundedPolygon.star(4, 1f, 0.6f, CornerRounding(0.5f)))
        "pentagon" -> PolyShape(RoundedPolygon(5, rounding = CornerRounding(0.2f)))
        "hexagon" -> PolyShape(RoundedPolygon(6, rounding = CornerRounding(0.2f)))
        else -> CircleShape
    }
}
