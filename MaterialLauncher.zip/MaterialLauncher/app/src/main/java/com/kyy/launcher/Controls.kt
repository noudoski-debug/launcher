package com.kyy.launcher

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

/** Ползунок в стиле Material 3 Expressive: толстая дорожка, зазор и вертикальная ручка. */
@Composable
fun M3Slider(
    value: Float, onChange: (Float) -> Unit, range: ClosedFloatingPointRange<Float>,
    modifier: Modifier = Modifier
) {
    val s = MaterialTheme.colorScheme
    val cur by rememberUpdatedState(onChange)
    val rng by rememberUpdatedState(range)
    var width by remember { mutableFloatStateOf(1f) }
    var dragging by remember { mutableStateOf(false) }
    val handle by animateDpAsState(if (dragging) 2.dp else 4.dp, label = "handle")
    val frac = ((value - range.start) / (range.endInclusive - range.start)).coerceIn(0f, 1f)
    val active = s.primary
    val inactive = s.secondaryContainer

    fun at(x: Float): Float = rng.start + (x / width).coerceIn(0f, 1f) * (rng.endInclusive - rng.start)

    Canvas(
        modifier.fillMaxWidth().height(44.dp)
            .onSizeChanged { width = it.width.toFloat().coerceAtLeast(1f) }
            .pointerInput(Unit) { detectTapGestures { cur(at(it.x)) } }
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragStart = { dragging = true; cur(at(it.x)) },
                    onDragEnd = { dragging = false },
                    onDragCancel = { dragging = false }
                ) { change, _ -> cur(at(change.position.x)) }
            }
    ) {
        val h = 16.dp.toPx()
        val cy = size.height / 2f
        val gap = 6.dp.toPx()
        val hw = handle.toPx()
        val hx = (size.width * frac).coerceIn(hw / 2f, size.width - hw / 2f)
        val aEnd = hx - hw / 2f - gap
        if (aEnd > 0f) drawRoundRect(active, Offset(0f, cy - h / 2f), Size(aEnd, h), CornerRadius(h / 2f))
        val iStart = hx + hw / 2f + gap
        if (iStart < size.width) {
            drawRoundRect(inactive, Offset(iStart, cy - h / 2f), Size(size.width - iStart, h), CornerRadius(h / 2f))
            if (size.width - iStart > h * 2f) drawCircle(active, 2.dp.toPx(), Offset(size.width - h / 2f, cy))
        }
        drawRoundRect(
            active, Offset(hx - hw / 2f, 2.dp.toPx()),
            Size(hw, size.height - 4.dp.toPx()), CornerRadius(hw / 2f)
        )
    }
}

/** Выбор варианта: выбранный — плотная плашка с более круглыми углами (M3 Expressive). */
@Composable
fun ChoiceChip(
    label: String, selected: Boolean, leading: (@Composable () -> Unit)? = null,
    onClick: () -> Unit
) {
    val s = MaterialTheme.colorScheme
    val k = prefs.corner / 100f
    val corner by animateDpAsState(((if (selected) 22 else 12) * k).dp, spring(0.7f, 600f), label = "corner")
    val bg by animateColorAsState(if (selected) s.primary else s.surfaceContainerHighest, label = "bg")
    val fg = if (selected) s.onPrimary else s.onSurfaceVariant
    Row(
        Modifier.clip(RoundedCornerShape(corner)).background(bg).clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (leading != null) { leading(); Spacer(Modifier.width(8.dp)) }
        Text(label, color = fg, fontWeight = FontWeight.Medium)
    }
}
