package com.kyy.launcher

import android.annotation.SuppressLint
import android.content.Context
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.GraphicsLayerScope
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp as lerpColor
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.math.sqrt

// ───────────── списки стилей (ключ → название) ─────────────

val OpenStyles = listOf(
    "pixel" to "Pixel", "bloom" to "Волна", "zoom" to "Масштаб", "slide" to "Шторка", "fade" to "Затухание"
)
val DrawerStyles = listOf(
    "slide" to "Подъём", "spring" to "Пружина", "scale" to "Рост", "rise" to "Мягкий", "fade" to "Затухание"
)
val PageEffects = listOf(
    "none" to "Обычное", "depth" to "Глубина", "cube" to "Куб", "zoom" to "Масштаб",
    "fan" to "Веер", "fade" to "Растворение", "stack" to "Стопка"
)
val UnlockStyles = listOf(
    "pixel" to "Google Pixel", "normal" to "Обычная", "zoom" to "Масштаб",
    "rise" to "Подъём", "drop" to "Падение", "fade" to "Затухание"
)
val SwipeDownActions = listOf(
    "notifications" to "Шторка уведомлений", "search" to "Поиск приложений", "none" to "Ничего"
)

// ───────────── общие величины ─────────────

/** Скорость анимаций как множитель: 1 = 100 %. */
fun animK(): Float = (prefs.animSpeed / 100f).coerceIn(0.25f, 3f)

/** Затухание пружин интерфейса: чем больше «Пружинистость», тем сильнее отскок. */
fun bounceDamping(): Float = (1f - 0.4f * prefs.animBounce / 100f).coerceIn(0.55f, 1f)

/** Затухание пружины нажатия на иконку. */
fun pressDamping(): Float = (0.9f - 0.55f * prefs.animBounce / 100f).coerceIn(0.3f, 0.95f)

private val EmphasizedOut = CubicBezierEasing(0.2f, 0f, 0f, 1f)
private val EmphasizedIn = CubicBezierEasing(0.3f, 0f, 0.8f, 0.15f)

// ───────────── анимация открытия приложения ─────────────

/**
 * Окно, которое вырастает из иконки. t = 0 — иконка, t = 1 — весь экран.
 * Рисуется и в самом лаунчере, и в предпросмотре на странице «Анимации».
 */
fun DrawScope.drawLaunchWindow(
    style: String, t: Float, r: Rect, startColor: Color, endColor: Color, cornerPx: Float, tile: Boolean
) {
    val tt = t.coerceIn(0f, 1f)
    val col = lerpColor(startColor, endColor, tt)
    val startR = if (tile) minOf(r.width, r.height) * 0.3f else minOf(r.width, r.height) / 2f
    when (style) {
        "bloom" -> {
            // круг растёт из иконки и заливает экран
            val c = r.center
            val dx = maxOf(c.x, size.width - c.x)
            val dy = maxOf(c.y, size.height - c.y)
            val maxR = sqrt(dx * dx + dy * dy)
            val rad = startR + (maxR - startR) * tt
            drawCircle(col.copy(alpha = (tt * 6f).coerceIn(0f, 1f)), radius = rad, center = c)
        }
        "zoom" -> {
            // уменьшенный «экран» приближается от иконки к центру и растёт до полного размера
            val s0 = maxOf(r.width / size.width, r.height / size.height).coerceIn(0.08f, 1f)
            val sc = s0 + (1f - s0) * tt
            val cx = r.center.x + (size.width / 2f - r.center.x) * tt
            val cy = r.center.y + (size.height / 2f - r.center.y) * tt
            val w = size.width * sc
            val h = size.height * sc
            val rad = (startR + (cornerPx - startR) * tt).coerceAtLeast(0f)
            drawRoundRect(
                color = col.copy(alpha = (tt * 5f).coerceIn(0f, 1f)),
                topLeft = Offset(cx - w / 2f, cy - h / 2f), size = Size(w, h), cornerRadius = CornerRadius(rad)
            )
        }
        "slide" -> {
            // окно выезжает снизу, как шторка
            val y = size.height * (1f - tt)
            drawRoundRect(
                color = col.copy(alpha = (tt * 4f).coerceIn(0f, 1f)),
                topLeft = Offset(0f, y), size = Size(size.width, size.height + cornerPx * 2f),
                cornerRadius = CornerRadius(cornerPx)
            )
        }
        "fade" -> {
            // экран проявляется на месте, чуть увеличиваясь
            val sc = 0.94f + 0.06f * tt
            val w = size.width * sc
            val h = size.height * sc
            drawRoundRect(
                color = col.copy(alpha = (tt * 1.25f).coerceIn(0f, 1f)),
                topLeft = Offset((size.width - w) / 2f, (size.height - h) / 2f), size = Size(w, h),
                cornerRadius = CornerRadius(cornerPx * tt)
            )
        }
        else -> {
            // Pixel: окно вырастает из самой иконки, углы плавно меняются
            val x = r.left * (1f - tt)
            val y = r.top * (1f - tt)
            val w = r.width + (size.width - r.width) * tt
            val h = r.height + (size.height - r.height) * tt
            val rad = (startR + (cornerPx - startR) * tt).coerceAtLeast(0f)
            drawRoundRect(
                color = col.copy(alpha = (tt * 6f).coerceIn(0f, 1f)),
                topLeft = Offset(x, y), size = Size(w, h), cornerRadius = CornerRadius(rad)
            )
        }
    }
}

/** Что делает сама иконка, пока открывается окно: растёт, летит к центру, гаснет. */
fun GraphicsLayerScope.launchIconFx(style: String, t: Float, r: Rect, screenW: Float, screenH: Float) {
    val k = t.coerceIn(0f, 1f)
    when (style) {
        "bloom" -> {
            val sc = 1f + k * 0.9f
            scaleX = sc; scaleY = sc
            alpha = (1f - k * 2.5f).coerceIn(0f, 1f)
        }
        "zoom" -> {
            val sc = 1f + k * 1.6f
            scaleX = sc; scaleY = sc
            translationX = (screenW / 2f - r.center.x) * k
            translationY = (screenH / 2f - r.center.y) * k
            alpha = (1f - k * 2.2f).coerceIn(0f, 1f)
        }
        "slide" -> {
            val sc = 1f + k * 0.2f
            scaleX = sc; scaleY = sc
            alpha = (1f - k * 3f).coerceIn(0f, 1f)
        }
        "fade" -> {
            val sc = 1f + k * 0.5f
            scaleX = sc; scaleY = sc
            alpha = (1f - k * 2f).coerceIn(0f, 1f)
        }
        else -> {
            val sc = 1f + k * 2.2f
            scaleX = sc; scaleY = sc
            translationX = (screenW / 2f - r.center.x) * k
            translationY = (screenH / 2f - r.center.y) * k
            alpha = (1f - k * 2f).coerceIn(0f, 1f)
        }
    }
}

private const val PV_W = 150f   // размеры макета телефона в предпросмотре, dp
private const val PV_H = 250f
private const val PV_ICON = 30f

private fun previewIconRect(density: Float): Rect {
    val cx = PV_W / 4f * 1.5f * density
    val cy = PV_H / 5f * 1.5f * density
    val h = PV_ICON / 2f * density
    return Rect(Offset(cx - h, cy - h), Size(h * 2f, h * 2f))
}

/** Живой образец анимации открытия: маленький телефон, из иконки которого раскрывается окно. */
@Composable
fun OpenAnimPreview(style: String, modifier: Modifier = Modifier) {
    val s = MaterialTheme.colorScheme
    val p = remember { Animatable(0f) }
    var round by remember { mutableIntStateOf(0) }
    val k = animK()
    LaunchedEffect(style, round, prefs.animSpeed) {
        p.snapTo(0f)
        delay(450)
        p.animateTo(1f, spring(dampingRatio = 1f, stiffness = 420f * k * k, visibilityThreshold = 0.002f))
        delay(550)
        p.animateTo(0f, spring(dampingRatio = 1f, stiffness = 150f * k * k, visibilityThreshold = 0.002f))
        delay(500)
        round++
    }
    val ph = s.primary
    val bgIcon = s.secondaryContainer
    val win = s.primaryContainer
    val end = s.surface
    Box(modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        Box(
            Modifier.width(PV_W.dp).height(PV_H.dp).clip(RoundedCornerShape(26.dp)).background(s.surfaceVariant)
        ) {
            Canvas(Modifier.fillMaxSize()) {
                val d = density
                val cols = 4
                val rows = 5
                val cw = size.width / cols
                val ch = size.height / rows
                for (cy in 0 until rows) for (cx in 0 until cols) {
                    if (cx == 1 && cy == 1) continue
                    drawCircle(bgIcon, radius = PV_ICON / 2f * d, center = Offset(cw * (cx + 0.5f), ch * (cy + 0.5f)))
                }
                val t = p.value
                if (t > 0.001f) {
                    drawLaunchWindow(style, t, previewIconRect(d), win, end, 22f * d, false)
                }
            }
            Box(
                Modifier
                    .offset(x = (PV_W / 4f * 1.5f - PV_ICON / 2f).dp, y = (PV_H / 5f * 1.5f - PV_ICON / 2f).dp)
                    .size(PV_ICON.dp)
                    .graphicsLayer {
                        val rr = previewIconRect(density)
                        launchIconFx(style, p.value, rr, PV_W.dp.toPx(), PV_H.dp.toPx())
                    }
                    .clip(shapeOf(prefs.iconShape)).background(ph)
            )
        }
    }
}

// ───────────── листание страниц рабочего стола ─────────────

/**
 * Эффект страницы при листании. o — смещение страницы от центра в долях ширины:
 * 0 — по центру, положительное — левее центра, отрицательное — правее. w — ширина страницы, px.
 * Обычный сдвиг делает сам список страниц, здесь только дополнительные преобразования.
 */
fun GraphicsLayerScope.applyPageFx(effect: String, o: Float, w: Float) {
    val oc = o.coerceIn(-1f, 1f)
    val a = abs(oc)
    when (effect) {
        "depth" -> if (oc < 0f) {
            // входящая страница стоит на месте и проявляется, уходящая уезжает как обычно
            alpha = 1f - a
            translationX = oc * w
            val sc = 0.75f + 0.25f * (1f - a)
            scaleX = sc; scaleY = sc
        }
        "cube" -> {
            cameraDistance = 14f * density
            transformOrigin = TransformOrigin(if (oc > 0f) 1f else 0f, 0.5f)
            rotationY = -90f * oc
        }
        "zoom" -> {
            val sc = (1f - 0.15f * a).coerceAtLeast(0.85f)
            scaleX = sc; scaleY = sc
            alpha = 0.5f + (1f - a) * 0.5f
        }
        "fan" -> {
            transformOrigin = TransformOrigin(0.5f, 1.3f)
            rotationZ = -oc * 12f
            alpha = 1f - 0.5f * a
            translationY = a * 30f
        }
        "fade" -> {
            alpha = 1f - a
            translationX = oc * w
        }
        "stack" -> if (oc > 0f) {
            // уходящая страница остаётся на месте под новой
            translationX = oc * w
            val sc = 1f - 0.1f * a
            scaleX = sc; scaleY = sc
            alpha = 1f - 0.6f * a
        }
        else -> {}
    }
}

@OptIn(ExperimentalFoundationApi::class)
fun Modifier.pageFx(state: PagerState, page: Int): Modifier = this.graphicsLayer {
    if (!prefs.animsEnabled || prefs.pageEffect == "none") return@graphicsLayer
    val o = (state.currentPage - page) + state.currentPageOffsetFraction
    if (abs(o) < 0.001f) return@graphicsLayer
    applyPageFx(prefs.pageEffect, o, size.width)
}

/** Образец эффекта листания: две страницы, которые сами перелистываются туда и обратно. */
@Composable
fun PageFxPreview(effect: String, modifier: Modifier = Modifier) {
    val s = MaterialTheme.colorScheme
    val pos = remember { Animatable(0f) }
    var w by remember { mutableIntStateOf(1) }
    LaunchedEffect(effect) {
        pos.snapTo(0f)
        while (true) {
            delay(600)
            pos.animateTo(1f, tween(750, easing = FastOutSlowInEasing))
            delay(600)
            pos.animateTo(0f, tween(750, easing = FastOutSlowInEasing))
        }
    }
    Box(
        modifier.fillMaxWidth().height(150.dp).clip(RoundedCornerShape(24.dp))
            .background(s.surfaceVariant).onSizeChanged { w = it.width.coerceAtLeast(1) }
    ) {
        listOf(0, 1).forEach { i ->
            val bg = if (i == 0) s.primaryContainer else s.tertiaryContainer
            val fg = if (i == 0) s.onPrimaryContainer else s.onTertiaryContainer
            Box(
                Modifier.fillMaxSize()
                    .offset { IntOffset((-(pos.value - i) * w).roundToInt(), 0) }
                    .graphicsLayer { applyPageFx(effect, pos.value - i, size.width) }
                    .padding(14.dp).clip(RoundedCornerShape(18.dp)).background(bg),
                contentAlignment = Alignment.Center
            ) { Text("${i + 1}", fontSize = 34.sp, fontWeight = FontWeight.Black, color = fg) }
        }
    }
}

// ───────────── меню приложений ─────────────

fun drawerEnter(on: Boolean, sp: Float): EnterTransition {
    if (!on) return EnterTransition.None
    fun ms(base: Int, floor: Int) = (base / sp).toInt().coerceAtLeast(floor)
    return when (prefs.drawerAnim) {
        "fade" -> fadeIn(tween(ms(260, 80)))
        "scale" -> scaleIn(
            tween(ms(340, 90), easing = EmphasizedOut), initialScale = 0.85f, transformOrigin = TransformOrigin(0.5f, 1f)
        ) + fadeIn(tween(ms(220, 60)))
        "spring" -> scaleIn(
            spring(dampingRatio = bounceDamping(), stiffness = 380f * sp * sp),
            initialScale = 0.8f, transformOrigin = TransformOrigin(0.5f, 1f)
        ) + fadeIn(tween(ms(160, 50)))
        "rise" -> slideInVertically(tween(ms(380, 100), easing = EmphasizedOut)) { it / 6 } +
            fadeIn(tween(ms(240, 70)))
        else -> slideInVertically(tween(ms(340, 90), easing = EmphasizedOut)) { it } +
            fadeIn(tween(ms(200, 60)))
    }
}

fun drawerExit(on: Boolean, sp: Float): ExitTransition {
    if (!on) return ExitTransition.None
    fun ms(base: Int, floor: Int) = (base / sp).toInt().coerceAtLeast(floor)
    return when (prefs.drawerAnim) {
        "fade" -> fadeOut(tween(ms(200, 60)))
        "scale", "spring" -> scaleOut(
            tween(ms(240, 80), easing = EmphasizedIn), targetScale = 0.88f, transformOrigin = TransformOrigin(0.5f, 1f)
        ) + fadeOut(tween(ms(200, 60)))
        "rise" -> slideOutVertically(tween(ms(260, 80), easing = EmphasizedIn)) { it / 6 } +
            fadeOut(tween(ms(200, 60)))
        else -> slideOutVertically(tween(ms(260, 80), easing = EmphasizedIn)) { it } +
            fadeOut(tween(ms(200, 60)))
    }
}

/** Строка меню приложений по очереди «всплывает» (только первые экраны и только один раз за открытие). */
@Composable
fun StaggerIn(seen: MutableSet<String>, key: String, index: Int, content: @Composable () -> Unit) {
    val enabled = prefs.animsEnabled && prefs.drawerStagger && key !in seen && index < 28
    val p = remember { Animatable(if (enabled) 0f else 1f) }
    LaunchedEffect(Unit) {
        if (enabled) {
            delay(index * 28L)
            p.animateTo(1f, spring(dampingRatio = 0.72f, stiffness = 380f))
        }
        seen.add(key)
    }
    Box(
        Modifier.graphicsLayer {
            val v = p.value
            alpha = v.coerceIn(0f, 1f)
            translationY = (1f - v) * 36.dp.toPx()
            val sc = 0.88f + 0.12f * v
            scaleX = sc; scaleY = sc
        }
    ) { content() }
}

/** Приложение строкой: иконка слева, название справа (режим «список» в меню приложений). */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppListRow(app: AppInfo, menu: List<MenuAction>, modifier: Modifier = Modifier) {
    val s = MaterialTheme.colorScheme
    val open = LocalOpen.current
    val launchPkg = LocalLaunchPkg.current
    val ctx = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val sc by animateFloatAsState(
        if (pressed) (prefs.pressDepth / 100f + 0.1f).coerceAtMost(1f) else 1f,
        spring(dampingRatio = pressDamping(), stiffness = 520f), label = "rowPress"
    )
    var show by remember { mutableStateOf(false) }
    var row by remember { mutableStateOf<Rect?>(null) }
    var icon by remember { mutableStateOf<Rect?>(null) }
    val size = prefs.drawerIconSize.coerceIn(40, 64)
    Box(modifier) {
        Row(
            Modifier.fillMaxWidth()
                .onGloballyPositioned { row = it.boundsInWindow() }
                .graphicsLayer { scaleX = sc; scaleY = sc }
                .clip(rc(22))
                .combinedClickable(
                    interactionSource = src, indication = null,
                    onClick = {
                        if (prefs.tapHaptic) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        open(app, icon)
                    },
                    onLongClick = { prefetchShortcuts(ctx, app.pkg); show = true }
                )
                .background(if (pressed) s.surfaceContainerHighest else Color.Transparent)
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .onGloballyPositioned { icon = it.boundsInWindow() }
                    .graphicsLayer { alpha = if (launchPkg(app.pkg, icon)) 0f else 1f }
            ) { AppIcon(app, size.dp) }
            Spacer(Modifier.width(16.dp))
            Text(
                app.label, color = s.onSurface, fontSize = 16.sp, fontWeight = FontWeight.Medium,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
        if (show) {
            val r = row
            FloatingMenu(
                r?.center?.x?.roundToInt() ?: 0, r?.top?.roundToInt() ?: 0, r?.bottom?.roundToInt() ?: 0,
                { show = false }
            ) { AppMenuContent(app, menu) { show = false } }
        }
    }
}

// ───────────── жесты и скрытые приложения ─────────────

/** Раскрывает шторку уведомлений. Нужно разрешение EXPAND_STATUS_BAR; на некоторых прошивках может не сработать. */
@SuppressLint("WrongConstant", "PrivateApi")
fun expandNotifications(ctx: Context) {
    try {
        val sb = ctx.getSystemService("statusbar")
        Class.forName("android.app.StatusBarManager").getMethod("expandNotificationsPanel").invoke(sb)
    } catch (_: Throwable) {
    }
}

fun hiddenSet(): Set<String> = prefs.hiddenApps.pkgs().toSet()
